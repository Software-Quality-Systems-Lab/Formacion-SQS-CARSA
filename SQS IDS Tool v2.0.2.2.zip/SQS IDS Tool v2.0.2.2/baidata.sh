#!/bin/bash
cd /home/baidata/Descargas/Release
wine Baidata_BFA.exe
